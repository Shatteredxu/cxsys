module.exports=(state,data)=>{
 return{ state:state,
    data:data
  } 
}